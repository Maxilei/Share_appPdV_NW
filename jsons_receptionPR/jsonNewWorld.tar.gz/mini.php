<?
session_start();
$host='localhost';
$user='gthom';
$pass='ini01';
$nomBase="dbgthomNewWorld";
mysql_connect($host,$user,$pass);
mysql_select_db('dbgthomNewWorld');
$base_url="http://gthom.btsinfogap.org/newWorld/";
$base=mysqli_connect($host,$user,$pass,$nomBase);
mysqli_query($base,"set collation utf8mb4_unicode_520_ci");
?>
